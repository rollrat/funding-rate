use chrono::Utc;
use uuid::Uuid;
use rand::Rng;
use crate::domain::{Order, OrderSide, OrderType, MarketSnapshot};
use crate::market::OrderFlowSource;

pub struct PassiveMM {
    spread_offset: f64, // e.g., 0.005 = 0.5% spread
}

impl PassiveMM {
    pub fn new(spread_offset: f64) -> Self {
        Self { spread_offset }
    }
}

impl OrderFlowSource for PassiveMM {
    fn generate(&self, snapshot: &MarketSnapshot) -> Vec<Order> {
        let mut orders = Vec::new();
        let mut rng = rand::thread_rng();

        // Only generate if we have a reference price
        let mid_price = match (snapshot.best_bid, snapshot.best_ask) {
            (Some(bid), Some(ask)) => (bid + ask) / 2.0,
            (Some(bid), None) | (None, Some(bid)) => bid,
            (None, None) => {
                snapshot.last_trade_price.unwrap_or(100.0)
            }
        };

        // Generate bid and ask orders around mid price
        if rng.gen_bool(0.6) {
            // Bid order (buy at mid - spread_offset)
            let bid_price = mid_price * (1.0 - self.spread_offset);
            orders.push(Order {
                id: Uuid::new_v4(),
                side: OrderSide::Buy,
                order_type: OrderType::Limit,
                price: Some(bid_price),
                quantity: rng.gen_range(5.0..=15.0),
                timestamp: Utc::now(),
            });
        }

        if rng.gen_bool(0.6) {
            // Ask order (sell at mid + spread_offset)
            let ask_price = mid_price * (1.0 + self.spread_offset);
            orders.push(Order {
                id: Uuid::new_v4(),
                side: OrderSide::Sell,
                order_type: OrderType::Limit,
                price: Some(ask_price),
                quantity: rng.gen_range(5.0..=15.0),
                timestamp: Utc::now(),
            });
        }

        orders
    }
}


use crate::domain::{Order, MarketSnapshot};
use crate::market::OrderFlowSource;

pub struct CompositeFlow {
    sources: Vec<Box<dyn OrderFlowSource + Send>>,
}

impl CompositeFlow {
    pub fn new(sources: Vec<Box<dyn OrderFlowSource + Send>>) -> Self {
        Self { sources }
    }
}

impl OrderFlowSource for CompositeFlow {
    fn generate(&self, snapshot: &MarketSnapshot) -> Vec<Order> {
        let mut all_orders = Vec::new();
        for source in &self.sources {
            let mut orders = source.generate(snapshot);
            all_orders.append(&mut orders);
        }
        all_orders
    }
}


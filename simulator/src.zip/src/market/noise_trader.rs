use chrono::Utc;
use uuid::Uuid;
use rand::Rng;
use crate::domain::{Order, OrderSide, OrderType, MarketSnapshot};
use crate::market::OrderFlowSource;

pub struct NoiseTrader;

impl OrderFlowSource for NoiseTrader {
    fn generate(&self, snapshot: &MarketSnapshot) -> Vec<Order> {
        let mut rng = rand::thread_rng();
        let mut orders = Vec::new();

        // Generate 0-2 random orders per tick
        let num_orders = rng.gen_range(0..=2);
        
        for _ in 0..num_orders {
            let side = if rng.gen_bool(0.5) {
                OrderSide::Buy
            } else {
                OrderSide::Sell
            };

            let order_type = if rng.gen_bool(0.7) {
                OrderType::Limit
            } else {
                OrderType::Market
            };

            let price = match order_type {
                OrderType::Limit => {
                    let base_price = snapshot.last_trade_price
                        .or(snapshot.best_bid)
                        .or(snapshot.best_ask)
                        .unwrap_or(100.0);
                    // Random price within ±2% of base
                    let offset = rng.gen_range(-0.02..=0.02);
                    Some(base_price * (1.0 + offset))
                }
                OrderType::Market => None,
            };

            let quantity = rng.gen_range(1.0..=10.0);

            orders.push(Order {
                id: Uuid::new_v4(),
                side,
                order_type,
                price,
                quantity,
                timestamp: Utc::now(),
            });
        }

        orders
    }
}


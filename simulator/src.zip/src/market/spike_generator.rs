use chrono::Utc;
use uuid::Uuid;
use rand::Rng;
use crate::domain::{Order, OrderSide, OrderType, MarketSnapshot};
use crate::market::OrderFlowSource;

pub struct SpikeGenerator {
    probability: f64, // e.g., 0.02 = 2% chance per tick
    max_quantity: f64,
}

impl SpikeGenerator {
    pub fn new(probability: f64, max_quantity: f64) -> Self {
        Self {
            probability,
            max_quantity,
        }
    }
}

impl OrderFlowSource for SpikeGenerator {
    fn generate(&self, _snapshot: &MarketSnapshot) -> Vec<Order> {
        let mut rng = rand::thread_rng();
        let mut orders = Vec::new();

        if rng.gen_bool(self.probability) {
            // Generate a large order spike
            let side = if rng.gen_bool(0.5) {
                OrderSide::Buy
            } else {
                OrderSide::Sell
            };

            // Large market order (price not needed for market orders)
            orders.push(Order {
                id: Uuid::new_v4(),
                side,
                order_type: OrderType::Market,
                price: None,
                quantity: rng.gen_range(self.max_quantity * 0.5..=self.max_quantity),
                timestamp: Utc::now(),
            });
        }

        orders
    }
}


pub mod noise_trader;
pub mod passive_mm;
pub mod spike_generator;
pub mod composite;

pub use noise_trader::NoiseTrader;
pub use passive_mm::PassiveMM;
pub use spike_generator::SpikeGenerator;
pub use composite::CompositeFlow;

use crate::domain::{Order, MarketSnapshot};

pub trait OrderFlowSource {
    fn generate(&self, snapshot: &MarketSnapshot) -> Vec<Order>;
}


use std::net::SocketAddr;
use std::sync::{Arc, RwLock};
use tokio::time::{interval, Duration};
use axum::{Router, routing::get, routing::post, Extension};

mod domain;
mod engine;
mod market;
mod gateway;
mod websocket;

use crate::engine::MatchingEngine;
use crate::market::{CompositeFlow, NoiseTrader, PassiveMM, SpikeGenerator, OrderFlowSource};
use crate::gateway::{get_orderbook, get_trades, post_order, OrderBookResponse, OrderJson};
use crate::websocket::{websocket_handler, create_broadcast, WebSocketMessage};

#[tokio::main]
async fn main() {
    // Initialize shared state
    let engine = Arc::new(RwLock::new(MatchingEngine::new()));

    // Set up market simulation sources
    let noise_trader = NoiseTrader;
    let passive_mm = PassiveMM::new(0.005); // e.g., 0.5% spread offset
    let spike_gen = SpikeGenerator::new(0.02, 50.0); // 2% chance per tick, up to 50 quantity

    let sources: Vec<Box<dyn market::OrderFlowSource + Send>> = vec![
        Box::new(noise_trader),
        Box::new(passive_mm),
        Box::new(spike_gen),
    ];
    let composite_flow = CompositeFlow::new(sources);

    // Create broadcast channel for WebSocket
    let broadcast_tx = create_broadcast();
    let broadcast_tx_clone = broadcast_tx.clone();

    // Spawn the simulation loop in a background task
    let engine_clone = engine.clone();
    tokio::spawn(async move {
        let mut ticker = interval(Duration::from_millis(50));
        loop {
            ticker.tick().await;
            // Step 1: get market snapshot (read lock)
            let snapshot = {
                let eng = engine_clone.read().unwrap();
                eng.get_snapshot()
            };
            // Step 2: generate orders from all sources
            let orders: Vec<domain::Order> = composite_flow.generate(&snapshot);
            if orders.is_empty() {
                continue; // skip if no orders generated this tick
            }
            // Step 3 & 4: submit orders to matching engine (write lock) and thus update orderbook & trades
            let mut eng = engine_clone.write().unwrap();
            let mut new_trades = Vec::new();
            for order in orders {
                // We ignore errors from engine here because our generators produce valid orders.
                // In a real scenario, we might log or handle EngineError.
                if let Ok(trades) = eng.submit_order(order) {
                    new_trades.extend(trades);
                }
            }
            
            // Broadcast updated orderbook via WebSocket
            let (bids, asks) = eng.get_orderbook();
            let bids_json: Vec<OrderJson> = bids
                .iter()
                .map(|o| OrderJson {
                    id: o.id,
                    side: format!("{:?}", o.side),
                    order_type: format!("{:?}", o.order_type),
                    price: o.price,
                    quantity: o.quantity,
                    timestamp: o.timestamp.to_rfc3339(),
                })
                .collect();
            let asks_json: Vec<OrderJson> = asks
                .iter()
                .map(|o| OrderJson {
                    id: o.id,
                    side: format!("{:?}", o.side),
                    order_type: format!("{:?}", o.order_type),
                    price: o.price,
                    quantity: o.quantity,
                    timestamp: o.timestamp.to_rfc3339(),
                })
                .collect();
            
            let orderbook = OrderBookResponse {
                bids: bids_json,
                asks: asks_json,
            };
            
            let _ = broadcast_tx_clone.send(WebSocketMessage::OrderBook(orderbook));
            
            // 새로운 trades만 브로드캐스트 (있는 경우에만)
            if !new_trades.is_empty() {
                let _ = broadcast_tx_clone.send(WebSocketMessage::Trades(new_trades));
            }
        }
    });

    // Build the REST API router with our routes and shared state
    let app = Router::new()
        .route("/orderbook", get(get_orderbook))
        .route("/trades", get(get_trades))
        .route("/order", post(post_order))
        .route("/ws", get(websocket_handler))
        .layer(Extension(engine.clone())) // provide engine state to handlers
        .layer(Extension(broadcast_tx.clone())); // provide broadcast channel to handlers

    // Start HTTP server
    let addr = SocketAddr::from(([127, 0, 0, 1], 3000));
    println!("Server running at http://{}", addr);
    
    let listener = tokio::net::TcpListener::bind(&addr).await
        .expect("Failed to bind to address");
    axum::serve(listener, app)
        .await
        .expect("Server failed to start");
}

